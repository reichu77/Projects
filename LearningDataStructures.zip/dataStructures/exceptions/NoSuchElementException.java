package dataStructures.exceptions;

public class NoSuchElementException extends RuntimeException{

}

