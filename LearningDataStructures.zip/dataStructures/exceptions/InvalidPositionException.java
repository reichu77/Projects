package dataStructures.exceptions;

public class InvalidPositionException extends RuntimeException{

}

