/**
 * @author André Gil (68533) agr.silva@fct.unl.pt
 * @author Glauco Ferreira (70833) gca.ferreira@fct.unl.pt
 */

import java.util.Scanner;

import homeway.*;
import dataStructures.*;

public class Main {

    private static final String HELP = "HELP";
    private static final String EXIT = "EXIT";
    private static final String BOUNDS = "BOUNDS";
    private static final String EATING = "EATING";
    private static final String LODGING = "LODGING";
    private static final String LEISURE = "LEISURE";
    private static final String SERVICES = "SERVICES";
    private static final String ADDSTUDENT = "STUDENT";
    private static final String LEAVE = "LEAVE";
    private static final String STUDENTS = "STUDENTS";
    private static final String GO = "GO";
    private static final String WHERE = "WHERE";
    private static final String FIND = "FIND";
    private static final String RANKING = "RANKING";
    private static final String RANKED = "RANKED";
    private static final String MOVE = "MOVE";
    private static final String STAR = "STAR";
    private static final String VISITED = "VISITED";


    private static final String MSG_COMMAND_UNKNOWN = "Unknown command. Type help to see available commands.";
    private static final String MSG_BYE = "Bye!";
    private static final String MSG_BOUNDS_NOT_DEFINED = "System bounds not defined.";
    private static final String MSG_CREATED = " created.";
    private static final String MSG_INVALID_BOUNDS = "Invalid bounds.";
    private static final String MSG_PRICE_INVALID_MENU = "Invalid menu price!";
    private static final String MSG_PRICE_INVALID_ROOM = "Invalid room price!";
    private static final String MSG_PRICE_INVALID_TICKET = "Invalid ticket price!";
    private static final String MSG_PRICE_INVALID_DISCOUNT = "Invalid discount!";
    private static final String MSG_ALREADY_THERE = "Already there!";
    private static final String MSG_LOCATION_INVALID = " location invalid!";    //name +
    private static final String MSG_ALREADY_EXISTS = " already exists!";    //name +
    private static final String MSG_NOT_EXITS = " does not exist!"; //name +
    private static final String MSG_ADDED = " added.";  //name +
    private static final String MSG_HAS_LEFT = " has left.";    //name +
    private static final String MSG_UNKNOWN = "Unknown %s!\n";  //<name>
    private static final String MSG_IS_NOW_AT = "%s is now at %s.\n";   //<user name, target name>
    private static final String MSG_IS_AT_DISTRACTED = "%s is now at %s. %s is distracted!\n";
                                                                                //<user name, target name, user name>
    private static final String MSG_IS_AT = "%s is at %s (%d, %d).\n";
                                                                    //<user name, service name, service Y, service X>
    private static final String MSG_NO_TYPE_SERVICES = "No %s services!\n";  //<service type>
    private static final String MSG_NO_TYPE_SERVICES_AVERAGE = "No %s services with average!\n";  //<service type>
    private static final String MSG_SERVICES_WITH_AVERAGE = "%s services with %d average\n"; //<service type, note>
    private static final String MSG_IS_THRIFTY = " is thrifty!";    //name +
    private static final String MSG_NOT_VISITED = " has not visited any locations!";    //name +
    private static final String MSG_NO_SERVICES_YET = "No services yet!";
    private static final String MSG_NO_SERVICES_IN_SYSTEM = "No services in the system.";
    private static final String MSG_NO_STUDENTS = "No students yet!";
    private static final String MSG_RANK = "Services sorted in descending order";
    private static final String MSG_LODGING = "Lodging ";   //+ name
    private static final String MSG_NO_SERVICE = "No %s services!\n";
    private static final String MSG_UPDATED = "%s updated.\n";
    private static final String MSG_EVALUATION_INVALID = "Invalid evaluation!";
    private static final String MSG_EVALUATION_REGISTERED = "Your evaluation has been registered!";
    private static final String MSG_STARS_INVALID = "Invalid stars!";


    private static final String HELP_BOUNDS = "bounds - Defines the geographic bounding rectangle of the system";
    private static final String HELP_EATING = "eating - Adds a new service of type eating to the system";
    private static final String HELP_LODGING = "lodging - Adds a new service of type lodging to the system";
    private static final String HELP_LEISURE = "leisure - Adds a new service of type leisure to the system";
    private static final String HELP_SERVICES = "services - Displays the list of services in the system";
    private static final String HELP_ADDSTUDENT = "student - Adds a student to the system";
    private static final String HELP_LEAVE = "leave - Removes a student from the system";
    private static final String HELP_STUDENTS = "students - Lists all the students in the community";
    private static final String HELP_GO = "go - Changes the location of a student to a service, or home";
    private static final String HELP_WHERE = "where - locates a student";
    private static final String HELP_FIND = "find - Finds the most relevant service of a certain type, for a specific student";
    private static final String HELP_RANKING = "ranking - lists services ordered by star";
    private static final String HELP_RANKED = "ranked - lists services of a certain type, with a specific star evaluation";
    private static final String HELP_MOVE = "move - changes the home of a student";
    private static final String HELP_STAR = "star - evaluates a service";
    private static final String HELP_VISITED = "visited - lists locations visited by one student";
    private static final String HELP_HELP = "help - shows the available commands";
    private static final String HELP_EXIT = "exit - terminates the execution of the program";
    private static final String MSG_SAME_HOME = "That is %s's home!\n"; //<name>
    private static final String MSG_MOVE_UNACCEPTABLE = "Move is not acceptable for %s!\n"; //<name>
    private static final String MSG_MOVE_SUCCESS = "%s is now %s's home. %s is home.\n";
                                                                        //<service name, student name, student name>

    private static final int CODE_SUCCESS = 0;
    private static final int CODE_NO_BOUNDS = -1;
    private static final int CODE_INVALID_PRICE = 1;
    private static final int CODE_OUTSIDE_BOUNDS = 2;
    private static final int CODE_DUPLICATED = 3;
    private static final int CODE_INVALID_DISCOUNT = 4;
    private static final int CODE_MISSING = 5;
    private static final int CODE_SUCCESS_UPDATED = 6;
    private static final int CODE_NO_SERVICE = 7;
    private static final int CODE_MISSING_LODGING = 8;
    private static final int CODE_SAME_HOME = 9;
    private static final int CODE_UNACCEPTABLE = 10;
    private static final int CODE_THRIFTY = 11;
    private static final int CODE_EMPTY = 12;
    private static final int CODE_INVALID_EVALUATION = 13;
    private static final int CODE_SERVICE_NOT_FOUND = 14;



    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        appClass app = new appClass();

        String command;                                    // Check if app.getHasBounds() for all except HELP and EXIT
        do {
            command = getCommand(in);
            switch (command) {
                case HELP -> showHelp(in);
                case EXIT -> exit();
                case BOUNDS -> defineBounds(in, app);
                case EATING -> addEating(in, app);
                case LODGING -> addLodging(in, app);
                case LEISURE -> addLeisure(in, app);
                case SERVICES -> services(app);
                case ADDSTUDENT -> addStudent(in, app);
                case STUDENTS -> students(app);
                case LEAVE -> leave(in, app);
                case GO -> go(in, app);
                case WHERE -> where(in, app);
                case STAR -> star(in,app);
                case RANKING -> ranking(in, app);
                case RANKED -> ranked(in,app);
                case MOVE -> move(in,app);
                case FIND -> find(in,app);
                case VISITED -> visited(in,app);

                default -> doDefault(in);
            }
        } while (!command.equals(EXIT));
        in.close();
    }

    /**
     * Writes the error message for an invalid command.
     * @param in scanner
     */
    private static void doDefault(Scanner in) {
        System.out.println(MSG_COMMAND_UNKNOWN);
        if(!in.hasNext())
            in.nextLine();
    }

    /**
     * Reads the next command.
     * @param in Scanner
     * @return the command in uppercase
     */
    private static String getCommand(Scanner in) {              //NOTE: It remains in the same line!
        return in.next().toUpperCase();                         //      Remember to pass when necessary.
    }

    /**
     * Prints what each command does.
     * @param in Scanner
     */
    private static void showHelp(Scanner in) {
        in.nextLine();
        System.out.println(HELP_BOUNDS);
        System.out.println(HELP_EATING);
        System.out.println(HELP_LODGING);
        System.out.println(HELP_LEISURE);
        System.out.println(HELP_SERVICES);
        System.out.println(HELP_ADDSTUDENT);
        System.out.println(HELP_STUDENTS);
        System.out.println(HELP_LEAVE);
        System.out.println(HELP_GO);
        System.out.println(HELP_MOVE);
        System.out.println(HELP_STAR);
        System.out.println(HELP_WHERE);
        System.out.println(HELP_VISITED);
        System.out.println(HELP_RANKING);
        System.out.println(HELP_RANKED);
        System.out.println(HELP_FIND);
        System.out.println(HELP_HELP);
        System.out.println(HELP_EXIT);
    }

    /**
     * Defines the System's bounds.
     * Reads top left corner's latitude and longitude,
     *      bottom right corner's latitude and longitude, and the name.
     * @param in Scanner
     * @param app app
     */
    private static void defineBounds(Scanner in, appClass app) {
        long y1 = in.nextLong();
        long x1 = in.nextLong();
        long y2 = in.nextLong();
        long x2 = in.nextLong();
        String name = in.nextLine().trim();

        if (y1 <= y2 || x1 >= x2) {
            app.deleteBounds();
            System.out.println(MSG_INVALID_BOUNDS);
        } else {
            app.defineBounds(y1, x1, y2, x2);
            System.out.println(name + MSG_CREATED);
        }
    }

    /**
     * Tries to create an Eating service to the system.
     * Reads latitude, longitude, price and name.
     * @param in Scanner
     * @param app app
     */
    private static void addEating(Scanner in, appClass app) {
        long y = in.nextLong();
        long x = in.nextLong();
        int price = in.nextInt();
        String name = in.nextLine().trim();

        switch (app.createEating(y,x,price,name)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_INVALID_PRICE -> System.out.println(MSG_PRICE_INVALID_MENU);
            case CODE_OUTSIDE_BOUNDS -> System.out.println(name + MSG_LOCATION_INVALID);
            case CODE_DUPLICATED -> System.out.println(name + MSG_ALREADY_EXISTS);
            case CODE_SUCCESS -> System.out.println(name + MSG_ADDED);
        }
    }

    /**
     * Tries to create a Lodging service to the system.
     * Reads latitude, longitude, price and name.
     * @param in Scanner
     * @param app app
     */
    private static void addLodging(Scanner in, appClass app) {
        long y = in.nextLong();
        long x = in.nextLong();
        int price = in.nextInt();
        String name = in.nextLine().trim();

        switch (app.createLodging(y,x,price,name)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_INVALID_PRICE -> System.out.println(MSG_PRICE_INVALID_ROOM);
            case CODE_OUTSIDE_BOUNDS -> System.out.println(name + MSG_LOCATION_INVALID);
            case CODE_DUPLICATED -> System.out.println(name + MSG_ALREADY_EXISTS);
            case CODE_SUCCESS -> System.out.println(name + MSG_ADDED);
        }
    }

    /**
     * Tries to create a Leisure service to the system.
     * Reads latitude, longitude, price, discount and name.
     * @param in Scanner
     * @param app app
     */
    private static void addLeisure(Scanner in, appClass app) {
        long y = in.nextLong();
        long x = in.nextLong();
        int price = in.nextInt();
        int discount = in.nextInt();
        String name = in.nextLine().trim();

        switch (app.createLeisure(y,x,price,discount,name)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_INVALID_PRICE -> System.out.println(MSG_PRICE_INVALID_TICKET);
            case CODE_INVALID_DISCOUNT -> System.out.println(MSG_PRICE_INVALID_DISCOUNT);
            case CODE_OUTSIDE_BOUNDS -> System.out.println(name + MSG_LOCATION_INVALID);
            case CODE_DUPLICATED -> System.out.println(name + MSG_ALREADY_EXISTS);
            case CODE_SUCCESS -> System.out.println(name + MSG_ADDED);
        }
    }

    /**
     * Lists all the services in the system.
     * @param app app
     */
    private static void services(appClass app) {
        if (!app.getHasBounds()){
            System.out.println(MSG_BOUNDS_NOT_DEFINED);
        } else if (app.hasServices()) {
            Iterator<Service> it =  app.iteratorServices();
            while( it.hasNext() ) {
                Service service = it.next();
                System.out.println(service.getName() + ": " + service.getType() + " " + service.getY() + " " + service.getX() + ".");
            }
        } else
            System.out.println(MSG_NO_SERVICES_YET);
    }

    /**
     * Tries to add a student. Reads the type, name and lodging's name.
     * @param in scanner
     * @param app app
     */
    private static void addStudent(Scanner in, appClass app) {
        String type = in.nextLine().trim();
        String name = in.nextLine().trim();
        String lodging = in.nextLine().trim();

        switch (app.addStudent(type, name, lodging)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_DUPLICATED -> System.out.println(name + MSG_ALREADY_EXISTS);
            case CODE_MISSING -> System.out.println(MSG_LODGING + lodging + MSG_NOT_EXITS);
            case CODE_SUCCESS -> System.out.println(name + MSG_ADDED);
        }
    }

    /**
     * Tries to remove a student form the system. Reads the student's name.
     * @param in scanner
     * @param app app
     */
    private static void leave(Scanner in, appClass app) {
        String name = in.nextLine().trim();

        switch (app.removeStudent(name)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_MISSING -> System.out.println(name + MSG_NOT_EXITS);
            case CODE_SUCCESS -> System.out.println(name + MSG_HAS_LEFT);
        }
    }

    /**
     * Tries ti list all students
     * @param app app
     */
    private static void students(appClass app) {
        if (!app.getHasBounds()){
            System.out.println(MSG_BOUNDS_NOT_DEFINED);
        } else if (app.hasStudents()) {
            Iterator<Student> it =  app.iteratorStudent();
            while( it.hasNext() ) {
                Student student = it.next();
                System.out.println(student.getName() + ": " + student.getType() + " at " + student.getCurrentLocationName() + ".");
            }
        }
        else System.out.println(MSG_NO_STUDENTS);
    }

    /**
     * Tries to move a student. reads student name and target location name.
     * @param in scanner
     * @param app app
     */
    private static void go(Scanner in, appClass app) {
        String studentName = in.nextLine().trim();
        String targetName = in.nextLine().trim();

        switch (app.go(studentName, targetName)){
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_MISSING -> System.out.println(studentName + MSG_NOT_EXITS);
            case CODE_OUTSIDE_BOUNDS -> System.out.printf(MSG_UNKNOWN, targetName);
            case CODE_DUPLICATED -> System.out.println(MSG_ALREADY_THERE);
            case CODE_INVALID_PRICE -> System.out.printf(MSG_IS_AT_DISTRACTED,studentName,targetName,studentName);
            case CODE_SUCCESS -> System.out.printf(MSG_IS_NOW_AT,studentName,targetName);
        }
    }

    /**
     * Tries to change a Student's home. Reads student's name and new home's name.
     * @param in scanner
     * @param app app
     */
    private static void move(Scanner in, appClass app) {
        String studentName = in.nextLine().trim();
        String lodgingName = in.nextLine().trim();

        switch (app.move(studentName, lodgingName)) {
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_MISSING -> System.out.println(studentName + MSG_NOT_EXITS);
            case CODE_MISSING_LODGING -> System.out.println(MSG_LODGING + lodgingName + MSG_NOT_EXITS);
            case CODE_SAME_HOME -> System.out.printf(MSG_SAME_HOME, studentName);
            case CODE_UNACCEPTABLE -> System.out.printf(MSG_MOVE_UNACCEPTABLE, studentName);
            case CODE_SUCCESS -> System.out.printf(MSG_MOVE_SUCCESS, lodgingName, studentName, studentName);
        }
    }

    /**
     * Writes the exist mesage.
     */
    private static void exit() {
        System.out.println(MSG_BYE);
    }

    /**
     * Tries to write student's current location.
     * @param in scanner
     * @param app app
     */
    private static void where(Scanner in,appClass app) {
        String studentName = in.nextLine().trim();

        if (!app.getHasBounds()){
            System.out.println(MSG_BOUNDS_NOT_DEFINED);
        } else if (!app.isStudent(studentName)){
            System.out.println(studentName + MSG_NOT_EXITS);
        } else {
            long X = app.whereX(studentName);
            long Y = app.whereY(studentName);
            String locationN = app.getCurrentServiceName(studentName);
            System.out.printf(MSG_IS_AT, studentName,locationN,Y,X);
        }
    }

    /**
     * Tries to evaluate a service. Reads evaluation number and name of service.
     * @param in scanner
     * @param app app
     */
    private static void star(Scanner in, appClass app) {
        int star = in.nextInt();
        String name = in.nextLine().trim();

        switch (app.star(name, star)) {
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_SERVICE_NOT_FOUND -> System.out.println(name + MSG_NOT_EXITS);
            case CODE_INVALID_EVALUATION -> System.out.println(MSG_EVALUATION_INVALID);
            case CODE_SUCCESS -> System.out.println(MSG_EVALUATION_REGISTERED);
        }
    }

    /**
     * Tries to list all the saved services of a given student. Reads the student's name.
     * @param in scanner
     * @param app app
     */
    private static void visited(Scanner in, appClass app) {
        String name = in.nextLine().trim();

        switch (app.visited(name)) {
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_MISSING -> System.out.println(name + MSG_NOT_EXITS);
            case CODE_THRIFTY -> System.out.println(name + MSG_IS_THRIFTY);
            case CODE_EMPTY -> System.out.println(name + MSG_NOT_VISITED);
            case CODE_SUCCESS -> {
                Iterator<Service> it = app.getLocationIterator(name);
                while (it.hasNext()) {
                    System.out.println(it.next().getName());
                }
            }
        }
    }

    /**
     * Tries to list all services by order of reviews.
     * @param in scanner
     * @param app app
     */
    private static void ranking(Scanner in, appClass app){
        in.nextLine();

        if(!app.getHasBounds()){
            System.out.println(MSG_BOUNDS_NOT_DEFINED);
        } else if (app.hasServices()) {
            System.out.println(MSG_RANK);

            Iterator<Service> it =  app.iteratorRanking();

            while( it.hasNext() ) {
                Service service = it.next();
                System.out.println(service.getName() + ": " + service.returnScore());
            }
        } else
            System.out.println(MSG_NO_SERVICES_IN_SYSTEM);
    }

    /**
     * Tries to list all the services of a certain type with a certain average grade.
     * Reads the type of service and the desired rating.
     * @param in scanner
     * @param app app
     */
    private static void ranked(Scanner in, appClass app) {
        String type = in.next().trim().toLowerCase();
        int min = in.nextInt();
        in.nextLine();

        switch (app.validateRanked(type, min)) {
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_INVALID_EVALUATION -> System.out.println(MSG_STARS_INVALID);
            case CODE_SERVICE_NOT_FOUND -> System.out.printf(MSG_NO_TYPE_SERVICES, type);
            case CODE_MISSING -> System.out.printf(MSG_NO_TYPE_SERVICES_AVERAGE, type);
            case CODE_SUCCESS -> {
                Iterator<Service> it = app.iteratorFiltered(min,type);
                System.out.printf(MSG_SERVICES_WITH_AVERAGE,type,min);
                while (it.hasNext()) {
                    Service service = it.next();
                    System.out.println(service.getName());
                }
            }
        }
    }

    /**
     * Tries to find the most interesting service for a player. Reads student's name and the type of service.
     * @param in scanner
     * @param app app
     */
    private static void find(Scanner in, appClass app) {
        String name = in.nextLine().trim();
        String type = in.nextLine().trim().toLowerCase();

        switch (app.find(name, type)) {
            case CODE_NO_BOUNDS -> System.out.println(MSG_BOUNDS_NOT_DEFINED);
            case CODE_MISSING -> System.out.println(name + MSG_NOT_EXITS);
            case CODE_NO_SERVICE -> System.out.printf(MSG_NO_SERVICE, type);
            case CODE_SUCCESS_UPDATED -> {
                System.out.println(app.findMessage(name, type));
                System.out.printf(MSG_UPDATED, name);
            }
            case CODE_SUCCESS -> {
                System.out.println(app.findMessage(name,type));
            }
        }
    }

}

