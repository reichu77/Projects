package homeway;
import dataStructures.*;

public interface Student {

    /**
     * @return student's type
     */
    String getType();

    /**
     * @return student's name
     */
    String getName();

    /**
     * @return return the name of the student's current location
     */
    String getCurrentLocationName();

    /**
     * @return return the name of the student's current home
     */
    String getHomeName();

    /**
     * @return return the student's current location
     */
    Service getCurrentLocation();

    /**
     * @return return the student's home
     */
    Service getHome();

    /**
     * Changes the student's home (not the location)
     * @param lodging new home
     * @pre: !lodging.equals(this.home)
     */
    void changeHome(Service lodging);

    /**
     * @param other another student
     * @return true if both have the same name, false if not.
     */
    boolean equals(Student other);

    /**
     * Changes student's current location
     * @param target
     */
    void go(Service target);

    /**
     * @return true if there are no saved locations, false if there are.
     */
    boolean visited0();

    /**
     * @return an iterator with the saved services of the student
     */
    Iterator<Service> iterator();

    /**
     * Saves the given service (if it is the right type)
     * @param target service to save
     */
    void save(Service target);
}
