package homeway;

public interface StudentThriftyInterface extends Student{
    /**
     * @param type
     * @returns true if there is no service stored of the given type
     */
    boolean hasStored(String type);

    /**
     * @return favourite eating service
     */
    Service getFavEating();

    /**
     * @return favourite lodging service
     */
    Service getFavLodging();

    /**
     * @param other service to compare
     * @return true if given service is cheaper than the favourite service of its type, false if not
     */
    boolean isCheaper(Service other);

    /**
     * @param other service to compare
     * @return true if given service is the same price as the favourite service of its type, false if not
     */
    boolean isSamePrice(Service other);
}
