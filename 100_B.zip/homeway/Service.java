package homeway;

public interface Service {

    /**
     * Ads a new evaluation to the service.
     * @param e evaluation number
     * @pre: 1 <= e <= 5
     */
    void addEvaluation(int e);

    /**
     * @return service's name
     */
    String getName();

    /**
     * @return service's type as a string
     */
    String getType();

    /**
     * @return the rounded reviews average
     */
    int returnScore();

    /**
     * @return service's latitude
     */
    long getY();

    /**
     * @return service's longitude
     */
    long getX();

    /**
     * @param other another service
     * @return true if both have the same name, false if not.
     */
    boolean equals(Service other);

    /**
     * @return the service's price
     */
    double getPrice();
}