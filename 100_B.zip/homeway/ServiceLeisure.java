package homeway;

public class ServiceLeisure extends ServiceClass{

    private final String type = "leisure";

    int ticketPrice;
    int discount;

    public ServiceLeisure(long y, long x, String name, int price, int discount){
        super(y,x,name);
        this.ticketPrice = price;
        this.discount = discount;

    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getPrice() {
        return (ticketPrice-(ticketPrice*((double)discount/100)));
    }
}
