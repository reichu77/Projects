package homeway;

import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.ArrayIteratorClass;
import dataStructures.Iterator;

public class StudentBookish extends StudentClass {

    private final String type = "bookish";
    private Service currentLocation;
    private Array<Service> visited;

    public StudentBookish(String name, Service Lodging) {
        super(name, Lodging);
        visited = new ArrayClass<Service>();
        go(Lodging);
    }

    @Override
    public String getCurrentLocationName() {
        return currentLocation.getName();
    }

    @Override
    public Service getCurrentLocation() {
        return currentLocation;
    }

    @Override
    public void go(Service target) {
        save(target);
        currentLocation = target;
    }

    @Override
    public boolean visited0() {
        return visited.size() == 0;
    }

    @Override
    public Iterator<Service> iterator() {
        return visited.iterator();
    }

    @Override
    public void save(Service target) {
        if(!visited.searchForward(target)){
            if (target instanceof ServiceLeisure){
                visited.insertLast(target);
            }
        }
    }

    @Override
    public String getType() {
        return type;
    }
}
