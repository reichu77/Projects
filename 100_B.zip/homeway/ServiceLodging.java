package homeway;

public class ServiceLodging extends ServiceClass{

    private final String type = "lodging";

    private int roomPrice;

    public ServiceLodging(long y, long x, String name, int price){
        super(y,x,name);
        this.roomPrice = price;

    }

    @Override
    public String getType() {
        return type;
    }


    @Override
    public double getPrice() {
        return roomPrice;
    }
}
