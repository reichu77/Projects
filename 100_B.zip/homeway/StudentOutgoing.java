package homeway;

import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.Iterator;

public class StudentOutgoing extends StudentClass {

    private final String type = "outgoing";
    private Array<Service> visited;
    private Service currentLocation;

    public StudentOutgoing(String name, Service Lodging) {
        super(name, Lodging);
        visited = new ArrayClass<Service>();
        go(Lodging);
    }

    @Override
    public String getCurrentLocationName() {
        return currentLocation.getName();
    }

    @Override
    public Service getCurrentLocation() {
        return currentLocation;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void go(Service target) {
        save(target);
        currentLocation = target;
    }

    @Override
    public boolean visited0() {
        return visited.size() == 0;
    }

    @Override
    public Iterator<Service> iterator() {
        return visited.iterator();
    }

    @Override
    public void save(Service target) {
        if(!visited.searchForward(target)){
            visited.insertLast(target);
        }
    }
}
