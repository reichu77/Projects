package homeway;

public abstract class ServiceClass implements Service{

    private String name;
    private long y;
    private long x;
    private int counter;
    private int[] evaluations;

    public ServiceClass(long y, long x, String name){
        this.name = name;
        this.y = y;
        this.x = x;
        counter = 0;
        evaluations = new int[0];
        addEvaluation(4);
    }

    @Override
    public void addEvaluation(int e) {
        int[] array = new int[counter+1];
        for (int i = 0; i < counter; i++){
            array[i] = evaluations[i];
        }
        array[counter] = e;
        counter++;
        evaluations = array;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public long getY() {
        return y;
    }

    @Override
    public long getX() {
        return x;
    }

    @Override
    public int returnScore() {
        int e = 0;
        for (int i = 0; i < counter; i++) {
            e += evaluations[i];
        }
        return Math.round((float) e / counter);
    }

    @Override
    public boolean equals(Service obj){
        ServiceClass other = (ServiceClass) obj;
        return this.name.equals(other.name);
    }

    public abstract double getPrice();
}