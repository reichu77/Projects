package homeway;

import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.Iterator;

public class StudentThrifty extends StudentClass implements StudentThriftyInterface {

    private final String type = "thrifty";
    private Service currentLocation;
    private Service favLodging;
    private Service favEating;

    public StudentThrifty(String name, Service Lodging) {
        super(name, Lodging);
        go(Lodging);
    }

    @Override
    public String getCurrentLocationName() {
        return currentLocation.getName();
    }

    @Override
    public Service getCurrentLocation() {
        return currentLocation;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void go(Service target) {
        save(target);
        currentLocation = target;
    }

    @Override
    public boolean visited0() {
        return false;
    }

    @Override
    public Iterator<Service> iterator() {
        return null;
    }

    @Override
    public void save(Service target) {
        if (target instanceof ServiceEating){
            if (favEating == null){
                favEating = target;
            } else if (favEating.getPrice() > target.getPrice()){
                favEating = target;
            }
        } else if(target instanceof ServiceLodging){
            if (favLodging == null){
                favLodging = target;
                changeHome(target);
            } else if (favLodging.getPrice() > target.getPrice()){
                favLodging = target;
                changeHome(target);
            }
        }
    }

    @Override
    public boolean hasStored(String type) {
        boolean result = false;
        switch (type.toLowerCase()){
            case "lodging" -> {
                if (favLodging != null)
                    result = true;
            }
            case "leisure" -> {
                result = true;
            }
            case "eating" -> {
                if (favEating != null)
                    result = true;
            }
        }
        return result;
    }

    @Override
    public Service getFavEating() {
        return favEating;
    }

    @Override
    public Service getFavLodging() {
        return favLodging;
    }

    @Override
    public boolean isCheaper(Service other) {
        boolean result = false;
        if (other instanceof ServiceEating){
            if (favEating == null){
                result = true;
            } else if (favEating.getPrice() > other.getPrice()){
                result = true;
            }
        } else if(other instanceof ServiceLeisure){
            result = true;
        } else if(other instanceof ServiceLodging){
            if (favLodging == null){
                result = true;
            } else if (favLodging.getPrice() > other.getPrice()){
                result = true;
            }
        }
        return result;
    }

    @Override
    public boolean isSamePrice(Service other) {
        boolean result = false;
        if (other instanceof ServiceEating){
            if (favEating == null){
                result = true;
            } else if (favEating.getPrice() == other.getPrice()){
                result = true;
            }
        } else if(other instanceof ServiceLeisure){
            result = true;
        } else if(other instanceof ServiceLodging){
            if (favLodging == null){
                result = true;
            } else if (favLodging.getPrice() == other.getPrice()){
                result = true;
            }
        }
        return result;
    }
}
