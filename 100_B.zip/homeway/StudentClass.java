package homeway;

import dataStructures.Iterator;

public abstract class StudentClass implements Student{
    private String name;
    private Service home;

    public StudentClass(String name, Service home){
        this.name = name;
        this.home = home;
    }

    @Override
    public String getName(){
        return name;
    }

    public abstract String getCurrentLocationName();

    @Override
    public String getHomeName() {
        return home.getName();
    }

    public abstract Service getCurrentLocation();

    @Override
    public Service getHome(){
        return home;
    }

    @Override
    public void changeHome(Service lodging){
        home = lodging;
    }

    @Override
    public boolean equals(Student other){
        return this.name.equals(other.getName());
    }

    public abstract String getType();

    public abstract void go(Service target);

    public abstract boolean visited0();

    public abstract Iterator<Service> iterator();

    public abstract void save(Service target);
}
