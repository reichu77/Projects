package homeway;

public class ServiceEating extends ServiceClass{

    private final String type = "eating";

    private int menuPrice;

    public ServiceEating(long y, long x, String name, int price){
        super(y, x, name);
        this.menuPrice = price;

    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getPrice() {
        return menuPrice;
    }
}