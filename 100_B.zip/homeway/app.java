package homeway;

import dataStructures.Iterator;

public interface app {

 /**
  * @return true if Bounds have been set, false if not.
  */
 boolean getHasBounds();

 /**
  * Checks if the given information is correct for the Ranked function
  * @param type the service's type
  * @param n the service's evaluation average
  * @return 0 if successful, -1 if bounds have not been defined, 13 if evaluation is invalid,
  *    14 if sno services of type exist, 5 if no services with that average rating exist in that type.
  */
 int validateRanked(String type,int n);

 /**
  Tries to add an evaluation to a service.
  * @param name service's name
  * @param star evaluation number
  * @return 0 if successful, -1 id bounds are not defined, 14 if service doesn't exist,
  *    13 if evaluation number is not on valid.
  */
 int star(String name, int star);


 /**
  * Defines the system's bounds
  * @param y1 top left latitude
  * @param x1 top left longitude
  * @param y2 bottom right latitude
  * @param x2 bottom right longitude
  */
 void defineBounds(long y1, long x1, long y2, long x2);

 /**
  * Deletes the current bounds of the system.
  */
 void deleteBounds();

 /**
  * Tries to create an eating service.
  * @param y latitude
  * @param x longitude
  * @param price menu price
  * @param name service's name
  * @return 0 if successful, -1 if bounds haven't been defined, 1 if price is invalid,
  *    2 if is outside system bounds, 3 if name is already a service.
  */
 int createEating(long y, long x, int price, String name);

 /**
  * @return true if there are registered services in the system, false if not.
  */
 boolean hasServices();

 /**
  * Tries to create a lodging service.
  * @param y latitude
  * @param x longitude
  * @param price menu price
  * @param name service's name
  * @return 0 if successful, -1 if bounds haven't been defined, 1 if price is invalid,
  *    2 if is outside system bounds, 3 if name is already a service.
  */
 int createLodging(long y, long x, int price, String name);

 /**
  * Tries to create a leisure service.
  * @param y latitude
  * @param x longitude
  * @param price menu price
  * @param discount discount percentage
  * @param name service's name
  * @return 0 if successful, -1 if bounds haven't been defined, 1 if price is invalid,
  *    2 if is outside system bounds, 3 if name is already a service, 4 if discount is invalid.
  */
 int createLeisure(long y,long x, int price, int discount, String name);

 /**
  * Tries to add a new student;
  * @param type the student's type
  * @param name the student's name
  * @param lodging the student's residence
  * @return 0 if successful, -1 if bounds haven't been defined, 3 if the student already exits,
  *    5 if the lodging doesn't exist.
  */
 int addStudent(String type, String name, String lodging);

 /**
  * @return true in there are students in the system, false if not.
  */
 boolean hasStudents();

 /**
  * Tries to move a student to a service
  * @param studentN student's name
  * @param targetN service's name
  * @return 0 if entirely successful, 1 if student is moved against their preferences,
  *          -1 if bound haven't been defined, 5 if student doesn't exist, 2 if target service doesn't exist,
  *          3 if student is already in target location.
  */
 int go(String studentN, String targetN);

 /**
  * Checks if the given information is correct for the Find function.
  * @param name student's name
  * @param type service's type
  * @return 0 if entirely successful, -1 if bounds have not been defined, 5 if student does not exist,
  *    7 if service doesn't exist, 6 if student is thrifty.
  */
 int find(String name, String type);

 /**
  * Writes the apropriate message for the command find.
  * @param name student's name
  * @param type service type
  * @return the name of the most interesting service for the given student
  * @pre: there is at least one service that meets the requirements
  */
 String findMessage(String name, String type);

 /**
  * Tries to see if a student has visited locations
  * @param name student's name
  * @return 0 if successful, -1 if bounds haven't been defined, 5 if there is no such student,
  *    11 if student is thrifty, 12 if student has no saved locations.
  */
 int visited(String name);

 /**
  * Tries to move a student to a new home
  * @param name student's name
  * @param lodgingName new home's name
  * @return 0 if entirely successful, -1 if bound haven't been defined, 5 if there is no such student,
  *    8 if there is no such lodging, 9 if student's current home is already the new home,
  *    10 if student tries to move against their preferences.
  */
 int move(String name, String lodgingName);

 /**
  * @param studentName name of the student
  * @return the student's latitude
  */
 long whereY(String studentName);

 /**
  * @param studentName student's name
  * @return the student's longitude
  */
 long whereX(String studentName);

 /**
  * @param studentName student's name
  * @return the name of the student's current service
  */
 String getCurrentServiceName(String studentName);

 /**
  * Tries to remove a student
  * @param name student's name
  * @return 0 if successful, -1 if bounds haven't been defined, 5 if the student doesn't exist
  */
 int removeStudent(String name);

 /**
  * Checks if there is a student with the given name in the system.
  * @param name the student's name
  * @return true if there is, false if not
  */
 boolean isStudent(String name);

 /**
  * @return an iterator of all services
  */
 Iterator<Student> iteratorStudent();

 /**
  * @return an iterator with all services in the system
  */
 Iterator<Service> iteratorServices();

 /**
  * @return an iterator of all services by order of reviews
  */
 Iterator<Service> iteratorRanking();

 /**
  * Returns an iterator with services of a given type with given star number.
  * @param star rating number
  * @param type the service type
  * @return said iterator
  * @pre: 1 <= star <=5 && (type==Lodging||Leisure||Eating).
  */
 Iterator<Service> iteratorFiltered(int star, String type);

 /**
  * @param name student's name
  * @return an iterator of the student's saved services
  * @pre: isStudent() && !(instaceof StudentThrifty)
  */
 Iterator<Service> getLocationIterator(String name);
}

