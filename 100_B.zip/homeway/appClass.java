package homeway;
import dataStructures.*;

public class appClass implements app{

    private static final int CODE_SUCCESS = 0;
    private static final int CODE_NO_BOUNDS = -1;
    private static final int CODE_INVALID_PRICE = 1;
    private static final int CODE_OUTSIDE_BOUNDS = 2;
    private static final int CODE_DUPLICATED = 3;
    private static final int CODE_INVALID_DISCOUNT = 4;
    private static final int CODE_MISSING = 5;
    private static final int CODE_SUCCESS_UPDATED = 6;
    private static final int CODE_NO_SERVICE = 7;
    private static final int CODE_MISSING_LODGING = 8;
    private static final int CODE_SAME_HOME = 9;
    private static final int CODE_UNACCEPTABLE = 10;
    private static final int CODE_THRIFTY = 11;
    private static final int CODE_EMPTY = 12;
    private static final int CODE_INVALID_EVALUATION = 13;
    private static final int CODE_SERVICE_NOT_FOUND = 14;

    private static final String EATING = "eating";
    private static final String LEISURE = "leisure";
    private static final String LODGING = "lodging";

    private static final String BOOKISH = "bookish";
    private static final String OUTGOING = "outgoing";
    private static final String THRIFTY = "thrifty";

    private boolean hasBounds;  //true if the command bounds has been used at least once.
    private long tl_Y;          //Top Left coordinates.
    private long tl_X;
    private long br_Y;          //Bottom Right coordinates.
    private long br_X;
    private Array<Service> services;
    private Array<Student> students;

    private Array<Service> stars5;
    private Array<Service> stars4;
    private Array<Service> stars3;
    private Array<Service> stars2;
    private Array<Service> stars1;



    public appClass(){
        hasBounds = false;
        services = new ArrayClass<Service>();
        students = new ArrayClass<Student>();
        stars5 = new ArrayClass<Service>();
        stars4 = new ArrayClass<Service>();
        stars3 = new ArrayClass<Service>();
        stars2 = new ArrayClass<Service>();
        stars1 = new ArrayClass<Service>();
    }



    @Override
    public boolean getHasBounds() {
        return hasBounds;
    }

    @Override
    public int validateRanked(String type, int min) {
        int result;

        if (!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (min < 1 || min > 5) {
            result = CODE_INVALID_EVALUATION;
        } else if (!type.equalsIgnoreCase(LODGING) &&
                !type.equalsIgnoreCase(LEISURE) &&
                !type.equalsIgnoreCase(EATING)) {
            result = CODE_MISSING;
        } else {
            // Passes the type to lowercase
            String normalizedType = type.toLowerCase();

            int n;
            // Verifies if there are services with the given evaluation
            n = getServiceNumber(min, normalizedType);
            if (n == 0) {
                result = CODE_MISSING;
            } else {
                // Verifies if there are services of the given type
                n = getServiceNumber(0, normalizedType);
                if (n == 0) {
                    result = CODE_SERVICE_NOT_FOUND;
                } else {
                    result = CODE_SUCCESS;
                }
            }
        }
        return result;
    }


    /**
     * Looks for the amount of services of given type with given star number, (0 stars = no filter)
     * @param star rating number
     * @param type the service type
     * @return number of services that apply
     * @pre: 0 <= star <=5 && (type==lodging||leisure||eating).
     */
    private int getServiceNumber(int star, String type) {
        int result = 0;
        switch (star){
            case 0 ->{
                for (int i=0; i<services.size(); i++)
                    if (services.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
            case 1 ->{
                for (int i=0; i<stars1.size(); i++)
                    if (stars1.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
            case 2 ->{
                for (int i=0; i<stars2.size(); i++)
                    if (stars2.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
            case 3 ->{
                for (int i=0; i<stars3.size(); i++)
                    if (stars3.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
            case 4 ->{
                for (int i=0; i<stars4.size(); i++)
                    if (stars4.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
            case 5 ->{
                for (int i=0; i<stars5.size(); i++)
                    if (stars5.get(i).getType().toLowerCase().equals(type))
                        result++;
            }
        }
        return result;
    }

    @Override
    public int star(String name, int star) {
        int result;
        if (!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (!isService(name)) {
            result = CODE_SERVICE_NOT_FOUND;
        } else if (star < 1 || star > 5) {
            result = CODE_INVALID_EVALUATION;
        } else{
            result = CODE_SUCCESS;
            Service s = getService(name);
            updateStars(s,star);
        }
        return result;
    }

    /**
     * updates the star-organized service arrays.
     * @param recent the most recently updated service
     */
    private void updateStars(Service recent, int star) {
        int oldRating = recent.returnScore();
        recent.addEvaluation(star); // Adds the evaluation

        if (oldRating != recent.returnScore()) {
            // Removes the service from the star arrays, if it is present
            removeIfPresent(stars5, recent);
            removeIfPresent(stars4, recent);
            removeIfPresent(stars3, recent);
            removeIfPresent(stars2, recent);
            removeIfPresent(stars1, recent);

            int score = recent.returnScore();

            // Inserts the service in the star array of its new average
            switch (score) {
                case 5 -> stars5.insertLast(recent);
                case 4 -> stars4.insertLast(recent);
                case 3 -> stars3.insertLast(recent);
                case 2 -> stars2.insertLast(recent);
                case 1 -> stars1.insertLast(recent);

            }
        }
    }


    /**
     * Removes the service from the given array is it is present.
     * @param array given array
     * @param s given service
     */
    private void removeIfPresent(Array<Service> array, Service s) {
        int i = array.searchIndexOf(s);
        if (i != -1)
            array.removeAt(i);
    }


    @Override
    public void defineBounds(long y1, long x1, long y2, long x2) {
        services = new ArrayClass<Service>();
        students = new ArrayClass<Student>();
        stars5 = new ArrayClass<Service>();
        stars4 = new ArrayClass<Service>();
        stars3 = new ArrayClass<Service>();
        stars2 = new ArrayClass<Service>();
        stars1 = new ArrayClass<Service>();

        tl_Y = y1;
        tl_X = x1;
        br_Y = y2;
        br_X = x2;
        hasBounds = true;
    }

    @Override
    public void deleteBounds() {
        services = new ArrayClass<Service>();
        students = new ArrayClass<Student>();
        stars5 = new ArrayClass<Service>();
        stars4 = new ArrayClass<Service>();
        stars3 = new ArrayClass<Service>();
        stars2 = new ArrayClass<Service>();
        stars1 = new ArrayClass<Service>();
        tl_Y = 0;
        tl_X = 0;
        br_Y = 0;
        br_X = 0;
        hasBounds = false;
    }

    @Override
    public int createEating(long y, long x, int price, String name) {
        int result;
        if(!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (price <= 0){
            result = CODE_INVALID_PRICE;
        } else if (!inBounds(y,x)){
            result = CODE_OUTSIDE_BOUNDS;
        } else if (isService(name)){
            result = CODE_DUPLICATED;
        } else {
            Service newEating = new ServiceEating(y, x, name, price);
            services.insertLast(newEating);
            stars4.insertLast(newEating);
            result = CODE_SUCCESS;
        }
        return result;
    }

    @Override
    public boolean hasServices() {
        return services.size() > 0;
    }

    @Override
    public int createLodging(long y, long x, int price, String name) {
        int result;
        if(!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (price <= 0){
            result = CODE_INVALID_PRICE;
        } else if (!inBounds(y,x)){
            result = CODE_OUTSIDE_BOUNDS;
        } else if (isService(name)){
            result = CODE_DUPLICATED;
        } else {
            Service newLodging = new ServiceLodging(y, x, name, price);
            services.insertLast(newLodging);
            stars4.insertLast(newLodging);
            result = CODE_SUCCESS;
        }
        return result;
    }

    @Override
    public int createLeisure(long y, long x, int price, int discount, String name) {
        int result;
        if(!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (price <= 0) {
            result = CODE_INVALID_PRICE;
        }else if ((discount < 0) || (discount > 100)){
            result = CODE_INVALID_DISCOUNT;
        } else if (!inBounds(y,x)){
            result = CODE_OUTSIDE_BOUNDS;
        } else if (isService(name)){
            result = CODE_DUPLICATED;
        } else {
            Service newLeisure = new ServiceLeisure(y, x, name, price, discount);
            services.insertLast(newLeisure);
            stars4.insertLast(newLeisure);
            result = CODE_SUCCESS;
        }
        return result;
    }

    @Override
    public int addStudent(String type, String name, String lodging) {
        int result;
        if (!hasBounds){
            result = CODE_NO_BOUNDS;
        } else if (isStudent(name)) {
            result = CODE_DUPLICATED;
        } else if (!lodgingExists(lodging)){
            result = CODE_MISSING;
        } else {
            result = CODE_SUCCESS;
            switch (type.toLowerCase()) {
                case BOOKISH -> addBookish(name, lodging);
                case OUTGOING -> addOutgoing(name, lodging);
                case THRIFTY -> addThrifty(name, lodging);
            }
        }
        return result;
    }


    @Override
    public boolean hasStudents() {
        return students.size() > 0;
    }

    @Override
    public int go(String studentN, String targetN) {
        int result;
        if (!hasBounds){
            result = CODE_NO_BOUNDS;
        } else if (!isStudent(studentN)){
            result = CODE_MISSING;
        } else if (!isService(targetN) && !targetN.equals("home")){
            result = CODE_OUTSIDE_BOUNDS;
        } else {                                        //student and service exits
            Student student = getStudent(studentN);
            Service target;
            if (targetN.equals("home")){
                target = student.getHome();
            } else {
                target = getService(targetN);
            }
            if (student.getCurrentLocation().equals(target)){
                result = CODE_DUPLICATED;
            } else {                                                //student moved
                if (student instanceof StudentThrifty) {
                    StudentThriftyInterface thrifty = (StudentThriftyInterface) student;
                    if (targetN.equals("home")){
                        result = CODE_SUCCESS;
                    } else if (!thrifty.isCheaper(target) && !thrifty.isSamePrice(target)) {
                        result = CODE_INVALID_PRICE;
                    } else {
                        result = CODE_SUCCESS;
                    }
                } else {
                    result = CODE_SUCCESS;
                }
                student.go(target);
            }
        }
        return result;
    }

    @Override
    public int find(String name, String type) {
        int result = 100;  // Inicialização de result com um valor padrão

        if (!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (!isStudent(name)) {
            result = CODE_MISSING;
        } else if (getServiceNumber(0, type) == 0) {
            result = CODE_NO_SERVICE;
        } else {
            Student student = getStudent(name);
            if (student instanceof StudentThrifty) {
                StudentThriftyInterface thrift = (StudentThriftyInterface)student;

                if (getServiceNumber(0,type)>0) {
                    if (type.equals(LEISURE)){
                        result = CODE_SUCCESS;
                    } else {
                        int i = 0;
                        boolean cheap = false;
                        while (i<services.size() && !cheap){
                            Service s = services.get(i);
                            if (s.getType().equals(type) && thrift.isCheaper(s)) {
                                result = CODE_SUCCESS_UPDATED;
                                cheap = true; // If a cheaper service is found, loop stops.
                            } else {
                                result = CODE_SUCCESS;
                            }
                            i++;
                        }
                    }
                } else {
                    result = CODE_NO_SERVICE; // No services of the type
                }
            } else {
                result = CODE_SUCCESS; // For all non-thrifty students
            }
        }

        return result;
    }




    @Override
    public int visited(String name) {
        int result;
        if (!hasBounds){
            result = CODE_NO_BOUNDS;
        } else if (!isStudent(name)) {
            result = CODE_MISSING;
        } else {
            Student student = getStudent(name);

            if (student instanceof StudentThrifty) {
                result = CODE_THRIFTY;
            } else if (student.visited0()) {
                result = CODE_EMPTY;
            } else {
                result = CODE_SUCCESS;
            }
        }
        return result;
    }


    @Override
    public int move(String studentName, String lodgingName) {
        int result;
        if (!hasBounds) {
            result = CODE_NO_BOUNDS;
        } else if (!isStudent(studentName)) {
            result = CODE_MISSING;
        } else if (!lodgingExists(lodgingName)) {
            result = CODE_MISSING_LODGING;
        } else {
            Student student = getStudent(studentName);
            Service lodging = getService(lodgingName);

            if (student.getHome().equals(lodging)) {
                result = CODE_SAME_HOME;
            } else {
                if (student instanceof StudentThrifty) {
                    StudentThrifty thriftyStudent = (StudentThrifty) student;
                    if (!thriftyStudent.isCheaper(lodging)) {
                        result = CODE_UNACCEPTABLE;
                    } else {
                        result = CODE_SUCCESS;
                        student.go(lodging);
                        student.changeHome(lodging);
                    }
                } else {
                    result = CODE_SUCCESS;
                    student.go(lodging);
                    student.changeHome(lodging);
                }
            }
        }
        return result;
    }

    @Override
    public long whereY(String studentName) {
        Student student = getStudent(studentName);
        return student.getCurrentLocation().getY();
    }

    @Override
    public long whereX(String studentName) {
        Student student = getStudent(studentName);
        return student.getCurrentLocation().getX();
    }

    @Override
    public String getCurrentServiceName(String studentName) {
        Student student = getStudent(studentName);
        return student.getCurrentLocation().getName();
    }

    @Override
    public String findMessage(String name, String type) {
        Student student = getStudent(name);

        // Initializes 'current' as the first service of the type
        Service current = null;
        int u = 0;
        boolean found = false;
        while (u<services.size() && !found){
            Service s = services.get(u);
            if (s.getType().equals(type)) {
                current = s;
                found = true;
            }
            u++;
        }

        // (Pre-condition makes sure that at least one service of the right type exists)
        if (student instanceof StudentThrifty) {
            for (int i = 0; i < services.size(); i++) {
                Service s = services.get(i);
                if (s.getType().equals(type) && s.getPrice() < current.getPrice()) {
                    current = s;
                }
            }
        } else {
            for (int i = 0; i < services.size(); i++) {
                Service s = services.get(i);
                if (s.getType().equals(type) &&
                        distanceToPlayer(s, student) < distanceToPlayer(current, student)) {
                    current = s;
                }
            }
        }

        if (student instanceof StudentThriftyInterface)
            student.save(current);
        return current.getName();
    }


    /**
     * Calculates de distance of a given service to a student.
     * @param service given service
     * @param student given student
     * @return said distance
     */
    private long distanceToPlayer(Service service, Student student) {
        return (Math.abs(service.getY()-student.getCurrentLocation().getY()) + Math.abs(service.getX()-student.getCurrentLocation().getX()));
    }

    /**
     * Checks if there is a lodging service with the given name in the system.
     * @param name the service's name
     * @return true if there is, false if not
     */
    private boolean lodgingExists(String name) {
        int i = 0;
        boolean found = false;
        while(i<services.size() && !found){
            if(services.get(i).getName().equals(name) && services.get(i).getType().equals(LODGING)){
                found = true;
            }
            i++;
        }
        return found;
    }

    @Override
    public int removeStudent(String name) {
        int result;
        if (!hasBounds){
            result = CODE_NO_BOUNDS;
        } else if (!isStudent(name)) {
            result = CODE_MISSING;
        } else {
            result = CODE_SUCCESS;
            Student toRemove = getStudent(name);
            int pos = students.searchIndexOf(toRemove);
            students.removeAt(pos);
        }
        return result;
    }


    /**
     * Adds an outgoing student.
     * @param name student's name.
     * @param lodging student's initial lodging
     * @pre: !isStudent(name)
     */
    private void addOutgoing(String name, String lodging) {
        Service home = getService(lodging);
        Student outgoing = new StudentOutgoing(name,home);
        students.insertLast(outgoing);
    }

    /**
     * Adds a bookish student.
     * @param name student's name.
     * @param lodging student's initial lodging
     * @pre: !isStudent(name)
     */
    private void addBookish(String name, String lodging) {
        Service home = getService(lodging);
        Student bookish = new StudentBookish(name,home);
        students.insertLast(bookish);

    }

    /**
     * Adds a thrifty student.
     * @param name student's name.
     * @param lodging student's initial lodging
     * @pre: !isStudent(name)
     */
    private void addThrifty(String name, String lodging) {
        Service home = getService(lodging);
        StudentThriftyInterface thrifty = new StudentThrifty(name,home);
        students.insertLast(thrifty);
    }

    @Override
    public Iterator<Student> iteratorStudent() {
        return students.iterator();
    }

    /**
     * Checks if the given coordinates are inside the bounds of the system.
     * @param y latitude
     * @param x longitude
     * @return true if it's in the bounds, false if it's outside
     */
    private boolean inBounds(long y, long x){
        return (y<=tl_Y && y>=br_Y) && (x>=tl_X && x<=br_X);
    }

    /**
     * Checks if there is a service with the given name in the system.
     * @param name the service's name
     * @return true if there is, false if not
     */
    private boolean isService(String name){
        int i = 0;
        boolean found = false;
        while (i < services.size() & !found){
            if (services.get(i).getName().equals(name)){
                found = true;
            } else {
                i++;
            }
        }
        return found;
    }

    /**
     * @param name given name
     * @return the service with the given name
     * @pre: isService()
     */
    private Service getService(String name) {
        int i= 0;
        boolean found = false;
        while (i < services.size() && !found) {
            if (services.get(i).getName().equals(name)) {
                found = true;
            } else {
                i++;
            }
        }
        if (found) {
            return services.get(i);
        } else {
            return null;
        }
    }

    @Override
    public boolean isStudent(String name){
        int i = 0;
        boolean found = false;
        while (i < students.size() && !found) {
            if (students.get(i).getName().equals(name)) {
                found = true;
            } else {
                i++;
            }
        }
        return found;
    }

    /**
     * @param name given name
     * @return the student with the given name
     * @pre: isService()
     */
    private Student getStudent(String name) {
        int i = 0;
        boolean found = false;
        while (i < students.size() && !found) {
            if (students.get(i).getName().equals(name)) {
                found = true;
            } else {
                i++;
            }
        }
        if (found) {
            return students.get(i);
        } else {
            return null;
        }
    }

    @Override
    public Iterator<Service> iteratorServices() {
        return services.iterator();
    }

    @Override
    public Iterator<Service> iteratorRanking() {
        Array<Service> full = new ArrayClass<Service>();
        for (int i=0; i<stars5.size();i++)
            full.insertLast(stars5.get(i));
        for (int i=0; i<stars4.size();i++)
            full.insertLast(stars4.get(i));
        for (int i=0; i<stars3.size();i++)
            full.insertLast(stars3.get(i));
        for (int i=0; i<stars2.size();i++)
            full.insertLast(stars2.get(i));
        for (int i=0; i<stars1.size();i++)
            full.insertLast(stars1.get(i));
        return full.iterator();
    }

    @Override
    public Iterator<Service> iteratorFiltered(int star, String type) {
        Array<Service> filtered = new ArrayClass<Service>();
        switch (star){
            case 1 ->{
                for (int i=0; i<stars1.size(); i++)
                    if (stars1.get(i).getType().toLowerCase().equals(type))
                        filtered.insertLast(stars1.get(i));
            }
            case 2 ->{
                for (int i=0; i<stars2.size(); i++)
                    if (stars2.get(i).getType().toLowerCase().equals(type))
                        filtered.insertLast(stars2.get(i));
            }
            case 3 ->{
                for (int i=0; i<stars3.size(); i++)
                    if (stars3.get(i).getType().toLowerCase().equals(type))
                        filtered.insertLast(stars3.get(i));
            }
            case 4 ->{
                for (int i=0; i<stars4.size(); i++)
                    if (stars4.get(i).getType().toLowerCase().equals(type))
                        filtered.insertLast(stars4.get(i));
            }
            case 5 ->{
                for (int i=0; i<stars5.size(); i++)
                    if (stars5.get(i).getType().toLowerCase().equals(type))
                        filtered.insertLast(stars5.get(i));
            }
        }
        return filtered.iterator();
    }

    @Override
    public Iterator<Service> getLocationIterator(String name) {
        Student s = getStudent(name);
        return s.iterator();
    }


}
